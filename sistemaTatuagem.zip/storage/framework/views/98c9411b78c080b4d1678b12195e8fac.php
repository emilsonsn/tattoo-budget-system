<?php $__env->startSection('content'); ?>
<?php
    use App\Models\Orcamento;
    $name = $_GET['name'] ?? null;
    $date = $_GET['date'] ?? null;
    $orcamentos = Orcamento::query();

    if($name){
        $orcamentos->where('nome', $name);
    }

    if($date){
        $orcamentos->whereDate('created_at', $date);
    }

    $orcamentos = $orcamentos->get();
?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/sass/home.scss']); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Listagem de Orçamentos')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="container mt-5 table-container">
                        <form action="" class="row mb-4">
                            <div class="col-md-4">
                                <input type="text" value="<?php echo e($name); ?>" name="name" class="form-control" placeholder="Nome do cliente">
                            </div>
                            <div class="col-md-4">
                                <input type="date" value="<?php echo e($date); ?>" name="date" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <button class="btn btn-primary">Fitlrar</button>
                            </div>
                        </form>
                        <h1>Orçamentos Calculados</h1>
                        <?php if($orcamentos->isEmpty()): ?>
                            <h2><strong>Nenhum orçamento disponível</strong></h2>
                        <?php else: ?>
                            <table class="table table-bordered table-striped table-responsive">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Nome</th>
                                        <th>Email</th>
                                        <th>Celular</th>
                                        <th>Instagram</th>
                                        <th>Estado</th>
                                        <th>Cidade</th>
                                        <th>Tipo de Desenho</th>
                                        <th>Local</th>
                                        <th>Largura</th>
                                        <th>Altura</th>
                                        <th>Cicatriz</th>
                                        <th>Remoção</th>
                                        <th>Cores</th>
                                        <th>Valor</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orcamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orcamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($orcamento->nome); ?></td>
                                            <td><?php echo e($orcamento->email); ?></td>
                                            <td><?php echo e($orcamento->celular); ?></td>
                                            <td><?php echo e($orcamento->instagram); ?></td>
                                            <td><?php echo e($orcamento->estado); ?></td>
                                            <td><?php echo e($orcamento->cidade); ?></td>
                                            <td><?php echo e($orcamento->tipo_desenho); ?></td>
                                            <td><?php echo e($orcamento->local); ?></td>
                                            <td><?php echo e($orcamento->largura); ?></td>
                                            <td><?php echo e($orcamento->altura); ?></td>
                                            <td><?php echo e($orcamento->cicatriz); ?></td>
                                            <td><?php echo e($orcamento->remocao); ?></td>
                                            <td><?php echo e($orcamento->cores); ?></td>
                                            <td>R$ <?php echo e(number_format($orcamento->valor, 2, ',', '.')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emilsonsn/Área de trabalho/Emilson/Projetos/Maio/SistemaTatuagem/resources/views/home.blade.php ENDPATH**/ ?>